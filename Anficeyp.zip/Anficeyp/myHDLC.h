#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define FRAME_STATE (0)
#define FLAG_STATE (1)
#define BUFFER_SIZE (2048)

int is_flag(uint8_t c1, uint8_t c2);
int catch_HDLC_Frame(FILE *fin, uint8_t bit_buffer[BUFFER_SIZE * 8]);
int remove_zero(uint8_t bit_buffer[BUFFER_SIZE * 8], int frame_size);
int bit_trans(uint8_t *buffer, uint8_t *bit_buffer, int bit_buffer_size);