#include <stdio.h>
#include <stdlib.h>
#include "util.h"
#include "myHDLC.h"


int main(int argc, char *argv[]) {
	FILE *fin;
	uint8_t buffer[BUFFER_SIZE];
	uint8_t bit_buffer[BUFFER_SIZE * 8];
	int frame_size = 0, bit_buffer_size = 0;

	if ((fin = fopen("sample_link.bin", "rb")) == NULL) {
		printf("File error.");
		exit(1);
	}

	for(int frame_index = 0; !feof(fin) && frame_index < 2; frame_index++) {
		printf("----\n");
		printf("Frame%d\n", frame_index);
		frame_size = catch_HDLC_Frame(fin, bit_buffer);
		
		bit_buffer_size = remove_zero(bit_buffer, frame_size);
		printf("++++\n");
		for (int i = 0; i < bit_buffer_size; ++i) {
			printf("%d", bit_buffer[i]);
		}
		printf("\n");
		bit_trans(buffer, bit_buffer, bit_buffer_size);
		printHex(buffer, bit_buffer_size / 8);
		printf("----\n");
	}
	fclose(fin);
	return 0;
}