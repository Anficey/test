#include <stdio.h>
#include <stdint.h>

void printHex(uint8_t *p, size_t byte_size);
