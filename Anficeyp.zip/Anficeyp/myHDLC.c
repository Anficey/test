#include "myHDLC.h"
#include "util.h"

const unsigned char flag_lookup[] = {
	0xFC, 0xF9, 0xF3, 0xE7, 0xCF, 0x9F, 0x3F, 0x7E
};

// 判断标识符
int is_flag(uint8_t c1, uint8_t c2) {
	for (int j = 0; j < 8; ++j) {
		if (c1 == flag_lookup[j] && c2 == flag_lookup[j]) {
			return FLAG_STATE;
		}
	}
	return FRAME_STATE;
}

// 把一个帧按比特表示，bit_buffer中每一个元素是一比特
void trans_bit(uint8_t *buffer, uint8_t *bit_buffer, int frame_size) {
	for (int i = 0; i < frame_size; ++i) {
		for (int j = 0; j < 8; ++j) {
			bit_buffer[i * 8 + j] = (buffer[i] >> (7 - j)) & 0x01;
		}
	}
}

// 把一个帧按比特表示，bit_buffer中每一个元素是一比特
int bit_trans(uint8_t *buffer, uint8_t *bit_buffer, int bit_buffer_size) {
	memset(buffer, 0, sizeof(uint8_t) * bit_buffer_size / 8);
	for (int i = 0; i < bit_buffer_size; i++) {
		buffer[i / 8] ^= bit_buffer[i] << (7 - (i % 8));
	}
}

// 分离单独的帧
int catch_HDLC_Frame(FILE *fin, uint8_t bit_buffer[BUFFER_SIZE * 8]) {
	int i = 0, is_changed = 0;
	int frame_start = 0, frame_end = 0, frame_size = 0, frame_count = 0;
	uint8_t byte1 = fgetc(fin), byte2 = fgetc(fin); //连续两个字节
	uint8_t state1 = FLAG_STATE, state2 = FLAG_STATE;
	uint8_t buffer[BUFFER_SIZE];
	while (!feof(fin) && frame_end == 0) {
		byte1 = byte2;
		byte2 = fgetc(fin);
		state2 = is_flag(byte1, byte2);
		is_changed = (state1 != state2);
		state1 = state2;
		if (is_changed) {
			if (state2 == FRAME_STATE) {
				frame_start = i - 3;
			}
			else {
				frame_end = i;
				++frame_count;
				frame_size = frame_end - frame_start;
				fseek(fin, -frame_size, SEEK_CUR);
				fread(buffer, frame_size, 1, fin);
				printHex(buffer, frame_size);
				trans_bit(buffer, bit_buffer, frame_size);
				// for (int j = 0; j < frame_size * 8; ++j) {
				// 	printf("%d", bit_buffer[j]);
				// }
				printf("\n");
			}
		}
		i++;
	}
	return frame_size;
}

int remove_zero(uint8_t bit_buffer[BUFFER_SIZE * 8], int frame_size) {
	int one_length = 0, p_one_length = 0, i = 0;
	int start = 0, end = 0;
	while (i < frame_size * 8) {
		if (bit_buffer[i])
			one_length++;
		else if (one_length != 0) {
			if(one_length == 5) {
				bit_buffer[i] = 3;
			}
			else if (one_length == 6) {
				bit_buffer[i] = 2;
				if(start && !end)
					end = i - 7;
			}
			if(!start) {
				if(p_one_length == 6 && one_length != 6)
					start = i - one_length;
			}
			p_one_length = one_length;
			one_length = 0;
		}
		++i;
	}
	i = 0;
	for (int j = start; j < end; ++j) {
		if(bit_buffer[j] != 3)
			bit_buffer[i++] = bit_buffer[j];
	}
	printf("\nlength:%d bits or %d bytes\n", i, i / 8);
	return i;
}
// 0011100111113101111000010001111131110111113
// 001010101111011001010110001011101101011110001001110010111101110001111112011111120
