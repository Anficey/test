#include "util.h"

void printHex(uint8_t *p, size_t byte_size) {
	int i, j = 0, eachRow = 16;
	for (i = 0; i + j < byte_size + eachRow; i += eachRow) {
		printf("%04X ", i);
		for (j = 0; j < eachRow && i + j < byte_size; ++j) {
			printf("%02X", p[i + j]);
			if(j != eachRow - 1)
				putchar(' ');
		}
		putchar('\n');
	}
	putchar('\n');
}
